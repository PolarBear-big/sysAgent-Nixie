from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import os

from config import config
from core.llm_client import LLMClient
from core.ssh_manager import SSHManager
from core.agent_runner import AgentRunner
from config.logger import logger

app = FastAPI(title="AI Sysadmin Agent API")

# 配置 CORS，允许前端 React 本地跨域请求
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # 开发环境允许所有来源
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 初始化全局 Agent 单例
try:
    config.check_config()
    llm_client = LLMClient(api_key=config.LLM_API_KEY, model=config.LLM_MODEL_NAME)
    ssh_manager = SSHManager(
        host=config.SSH_HOST, port=config.SSH_PORT, 
        username=config.SSH_USERNAME, password=config.SSH_PASSWORD
    )
    agent = AgentRunner(llm_client=llm_client, ssh_manager=ssh_manager)
    logger.info("🚀 FastAPI 后端 Agent 核心已启动就绪！")
except Exception as e:
    logger.error(f"初始化失败: {e}")
    # 在实际生产中，这里可能需要重试逻辑

# 定义前端传来的数据结构
class ChatRequest(BaseModel):
    message: str

@app.post("/api/chat")
async def chat_endpoint(request: ChatRequest):
    """处理前端发来的文本指令"""
    if not request.message:
        raise HTTPException(status_code=400, detail="消息不能为空")
        
    try:
        response_text = agent.process_user_input(request.message)
        return {"status": "success", "reply": response_text}
    except Exception as e:
        logger.error(f"处理请求报错: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/health")
async def health_check():
    """用于前端心跳检测，确认后端存活"""
    return {"status": "ok", "message": "SuSu is online"}

if __name__ == "__main__":
    import uvicorn
    # 启动后端服务
    uvicorn.run(app, host="0.0.0.0", port=8000)