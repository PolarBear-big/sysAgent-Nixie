import sys
from config import config
from core.llm_client import LLMClient
from core.ssh_manager import SSHManager
from core.agent_runner import AgentRunner

def main():
    print("正在初始化 AI Sysadmin Agent 环境...")
    
    try:
        # 检查环境变量配置
        config.check_config()
        
        # 实例化 LLM 客户端
        llm_client = LLMClient(
            api_key=config.LLM_API_KEY,
            # base_url=config.LLM_BASE_URL,
            model=config.LLM_MODEL_NAME
        )
        print("LLM 核心已就绪。")
        
        # 实例化 SSH 管理器
        ssh_manager = SSHManager(
            host=config.SSH_HOST,
            port=config.SSH_PORT,
            username=config.SSH_USERNAME,
            password=config.SSH_PASSWORD
        )
        
        # 实例化总调度器
        agent = AgentRunner(
            llm_client=llm_client,
            ssh_manager=ssh_manager
        )
        
        # 启动交互式终端
        agent.start_interactive_shell()
        
    except ValueError as ve:
        print(f"\n[配置错误] {ve}")
        sys.exit(1)
    except ConnectionError as ce:
        print(f"\n[网络错误] {ce}")
        sys.exit(1)
    except Exception as e:
        print(f"\n[系统异常] 发生未捕获的错误: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()