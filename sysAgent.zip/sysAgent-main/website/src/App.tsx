import { useState, useRef, useEffect } from 'react';

interface Message {
  role: 'user' | 'agent';
  content: string;
}

function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isInitializing, setIsInitializing] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isConnected, setIsConnected] = useState(false); 
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  // 应用启动时，触发动态的开场巡检
  useEffect(() => {
    const fetchInitialStatus = async () => {
      try {
        // 向后端发送一条“隐式”的指令，查询系统运行状态
        const response = await fetch('http://localhost:8000/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            message: 'Boos刚刚登录了控制面板。请你做个简短的开场白，并调用工具真实查询一下当前服务器的CPU和内存运行状态，向Boos汇报系统运行状态。' 
          }),
        });
        
        const data = await response.json();
        if (data.status === 'success') {
          setMessages([{ role: 'agent', content: data.reply }]);
        } else {
          setMessages([{ role: 'agent', content: `[初始化异常] ${data.detail}` }]);
        }
      } catch (error) {
        setMessages([{ role: 'agent', content: '无法连接到服务器。' }]);
      } finally {
        setIsInitializing(false);
      }
    };

    fetchInitialStatus();
  }, []); // 空依赖数组，确保只在首次加载时执行一次

  // 心跳检测机制
  useEffect(() => {
    const checkConnection = async () => {
      // 2s的超时控制器
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2000);

      try {
        const response = await fetch(`http://localhost:8000/api/health?t=${new Date().getTime()}`, {
          method: 'GET',
          cache: 'no-store',
          signal: controller.signal // 绑定超时信号
        });
        
        clearTimeout(timeoutId); // 成功响应，清除超时
        setIsConnected(response.ok);
      } catch (error) {
        // 无论是网络拒绝连接、VS Code 隧道断开、还是强制超时，全部判定为离线
        console.log("心跳检测失败或超时:", error);
        setIsConnected(false);
      }
    };
    
    // 首次加载立即检测一次
    checkConnection();
    // 之后每 3s 轮询一次
    const interval = setInterval(checkConnection, 3000);
    return () => clearInterval(interval);
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = input.trim();
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('http://localhost:8000/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userMessage }),
      });

      const data = await response.json();
      if (data.status === 'success') {
        setMessages(prev => [...prev, { role: 'agent', content: data.reply }]);
      } else {
        setMessages(prev => [...prev, { role: 'agent', content: `[通信异常] ${data.detail}` }]);
      }
    } catch (error) {
      setMessages(prev => [...prev, { role: 'agent', content: `[网络错误] 无法连接到服务器，请检查后端是否启动。` }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleVoiceInput = () => {
    // 正在录音，点击button结束录音
    if (isRecording) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsRecording(false);
      return
    }

    // 未录音，点击button则执行录音逻辑
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("抱歉，您的浏览器暂时不支持语音识别。");
      return;
    }
    const recognition = new SpeechRecognition();
    recognitionRef.current = recognition;
    recognition.lang = 'zh-CN';
    recognition.interimResults = false;
    recognition.onstart = () => setIsRecording(true);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInput(prev => prev + transcript);
    };
    recognition.onerror = (event: any) => {
      console.error("语音识别异常:", event.error);
      setIsRecording(false);
    };
    recognition.onend = () => setIsRecording(false);
    recognition.start();
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50 text-gray-800 font-sans">
      
      {/* 顶部导航栏 */}
      <header className="flex items-center justify-between px-6 py-4 bg-white/80 backdrop-blur-md shadow-sm z-10 border-b border-gray-200">
        <div className="flex items-center gap-3">
          <img 
            src="/avatar.png" 
            alt="Nixie Avatar"
            className="w-10 h-10 rounded-full object-cover shadow-sm border border-[#00CED1] bg-white" 
          />
          <div>
            <h1 className="text-lg font-bold tracking-wide text-gray-800">Nixie</h1>
            <p className="text-xs text-gray-500 font-medium">您的专属服务器管家</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2 bg-gray-100 px-3 py-1.5 rounded-full border border-gray-200">
          <span className="relative flex h-2.5 w-2.5">
            {isConnected && <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>}
            <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${isConnected ? 'bg-emerald-500' : 'bg-red-500'}`}></span>
          </span>
          <span className="text-xs font-medium text-gray-600">
            {isConnected ? '后端已连接' : '后端未响应'}
          </span>
        </div>
      </header>

      {/* 聊天消息区域 */}
      <main className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
        {/* 如果正在初始化，显示特定的加载动画 */}
        {isInitializing ? (
          <div className="flex justify-start">
             <div className="bg-white border border-gray-100 rounded-2xl rounded-bl-sm px-5 py-4 flex items-center gap-3 shadow-sm text-gray-500 text-sm">
                <div className="w-4 h-4 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin"></div>
                Nixie 正在为您进行系统上线巡检...
             </div>
          </div>
        ) : (
          messages.map((msg, index) => (
            <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div 
                className={`max-w-[80%] rounded-2xl px-5 py-3.5 shadow-sm text-sm sm:text-base leading-relaxed ${
                  msg.role === 'user' 
                    ? 'bg-gradient-to-r from-indigo-500 to-violet-500 text-white rounded-br-sm' 
                    : 'bg-white border border-gray-100 text-gray-700 rounded-bl-sm whitespace-pre-wrap'
                }`}
              >
                {msg.content}
              </div>
            </div>
          ))
        )}
        
        {/* 正常的回复加载动画 */}
        {isLoading && !isInitializing && (
          <div className="flex justify-start">
            <div className="bg-white border border-gray-100 rounded-2xl rounded-bl-sm px-5 py-4 flex items-center gap-2 shadow-sm">
              <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </main>

      {/* 底部输入区域 */}
      <footer className="p-4 bg-white border-t border-gray-200">
        <div className="max-w-4xl mx-auto flex gap-3 relative items-end">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyPress}
            placeholder="告诉Nixie你想管理什么... (例如: 查看当前系统内存状态)"
            className="flex-1 bg-gray-50 border border-gray-300 rounded-xl px-4 py-3.5 text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 transition-all resize-none h-14 min-h-[56px] shadow-inner"
            rows={1}
            disabled={isLoading}
          />
          
          <button 
            onClick={handleVoiceInput}
            disabled={isLoading} 
            className={`flex-shrink-0 flex items-center justify-center w-14 h-14 rounded-xl border transition-all ${
              isRecording 
                ? 'bg-red-50 border-red-200 text-red-500 animate-pulse shadow-[0_0_15px_rgba(239,68,68,0.2)]' 
                : 'bg-gray-50 border-gray-300 hover:bg-gray-100 text-gray-500 hover:text-indigo-500'
            }`}
            // 动态提示文案
            title={isRecording ? "点击结束录音" : "点击开始语音输入"}
          >
            {isRecording ? '听...' : '🎤'}
          </button>

          <button
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
            className="flex-shrink-0 px-6 h-14 rounded-xl bg-gray-800 hover:bg-gray-900 text-white disabled:opacity-50 disabled:cursor-not-allowed font-medium transition-colors shadow-md"
          >
            发送
          </button>
        </div>
      </footer>
    </div>
  );
}

export default App;