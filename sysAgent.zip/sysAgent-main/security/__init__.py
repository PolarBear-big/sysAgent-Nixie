from .risk_control import RiskController

risk_controller = RiskController()

def check_command_safety(command: str) -> dict:
    return risk_controller.evaluate(command)