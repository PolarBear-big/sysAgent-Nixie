import re

class RiskController:
    """
    系统管理场景下的安全风控引擎。
    通过静态正则匹配和黑名单机制，防止 Agent 做出破坏性操作。
    """
    def __init__(self):
        # 绝对禁止的高危正则模式 (FATAL)
        self.fatal_patterns = [
            (r"rm\s+-r[fF]?\s+(/|/\*|/(etc|var|usr|root)(/.*)?)(\s|$)", "尝试删除系统核心目录"),
            (r"chmod\s+([0-7]{3}|-R)\s+(/|/(etc|var)(/.*)?)(\s|$)", "尝试大范围篡改系统核心目录权限"),
            (r"(>|>>)\s*(/etc/passwd|/etc/shadow|/etc/sudoers)(\s|$)", "尝试篡改关键安全配置"),
            (r"(tee(\s+-a)?|vi|vim|nano)\s+(/etc/passwd|/etc/shadow|/etc/sudoers)", "尝试提权覆写关键安全配置文件"),
            (r"mkfs\.(ext[34]|xfs)\s+/dev/.*", "尝试格式化磁盘"),
            (r"dd\s+if=.*of=/dev/.*", "尝试底层磁盘覆写")
        ]
        
        # 需二次确认的敏感正则模式 (WARNING)
        self.warning_patterns = [
            (r"rm\s+-r[fF]?\s+", "包含递归删除指令"),
            (r"userdel\s+.*", "涉及用户删除操作"),
            (r"reboot|shutdown|init\s+[06]", "涉及系统电源状态变更"),
            (r"systemctl\s+(stop|disable)\s+", "涉及停用系统核心服务")
        ]

    def evaluate(self, command: str) -> dict:
        """
        评估命令的安全等级。
        :return: {"level": "SAFE"|"WARNING"|"FATAL", "reason": "解释性原因"}
        """
        # 检查是否触碰绝对红线 (FATAL)
        for pattern, reason in self.fatal_patterns:
            if re.search(pattern, command):
                return {"level": "FATAL", "reason": reason}
                
        # 检查是否需要风险预警 (WARNING)
        for pattern, reason in self.warning_patterns:
            if re.search(pattern, command):
                return {"level": "WARNING", "reason": reason}
                
        # 安全指令
        return {"level": "SAFE", "reason": "指令安全"}