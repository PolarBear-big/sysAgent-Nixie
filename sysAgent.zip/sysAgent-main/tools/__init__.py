from .disk_tools import CheckDiskTool
from .process_tools import CheckProcessTool
from .file_tools import SearchFileTool
from .user_tools import ManageUserTool
from .sysinfo_tools import SystemInfoTool
from .command_tools import ExecuteCommandTool


REGISTERED_TOOLS = [
    CheckDiskTool(),
    CheckProcessTool(),
    SearchFileTool(),
    ManageUserTool(),
    SystemInfoTool(),
    ExecuteCommandTool()
]

def get_all_tool_schemas() -> list:
    return [tool.get_tool_schema() for tool in REGISTERED_TOOLS]

def get_tool_by_name(tool_name: str):
    for tool in REGISTERED_TOOLS:
        if tool.name == tool_name:
            return tool
    return None