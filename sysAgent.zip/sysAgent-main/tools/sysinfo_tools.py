from .base_tool import BaseTool

class SystemInfoTool(BaseTool):
    name = "get_system_status"
    description = "查询系统整体运行概况，包括内存使用率、系统负载和运行时间。"
    
    parameters = {
        "type": "object",
        "properties": {
            "info_type": {
                "type": "string",
                "enum": ["memory", "uptime", "os_version"],
                "description": "查询信息的维度"
            }
        },
        "required": ["info_type"]
    }

    def get_command(self, **kwargs) -> str:
        info_type = kwargs.get("info_type")

        if info_type == "memory":
            return "free -h"
        elif info_type == "uptime":
            return "uptime"
        elif info_type == "os_version":
            return "cat /etc/os-release | grep PRETTY_NAME"
            
        return "uname -a"