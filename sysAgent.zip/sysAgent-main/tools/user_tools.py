from .base_tool import BaseTool

class ManageUserTool(BaseTool):
    name = "manage_system_user"
    description = "用于管理系统内的普通用户，支持查询、创建和删除用户。（注意：创建和删除操作通常需要最高系统权限）"
    
    parameters = {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["query", "create", "delete"],
                "description": "操作类型。'query' 查用户信息，'create' 创建新用户，'delete' 删除用户。"
            },
            "username": {
                "type": "string",
                "description": "目标用户的登录名（只能包含小写字母、数字和下划线）"
            }
        },
        "required": ["action", "username"]
    }

    def get_command(self, **kwargs) -> str:
        action = kwargs.get("action")
        username = kwargs.get("username")

        # 简单的用户名合法性防护
        if not username.replace("_", "").isalnum():
            return f"echo '非法用户名格式拦截: {username}'"

        if action == "query":
            return f"id {username}"
            
        elif action == "create":
            # -m 自动创建家目录，-s 指定默认 Shell 为 bash
            return f"useradd -m -s /bin/bash {username} && echo '用户 {username} 创建成功。'"
            
        elif action == "delete":
            # -r 同时删除该用户的家目录和邮件池
            return f"userdel -r {username} && echo '用户 {username} 及家目录已清理。'"
            
        return "echo '未知的用户操作'"