from .base_tool import BaseTool

class SearchFileTool(BaseTool):
    name = "search_file_or_content"
    description = "在系统中按名称查找文件/目录，或者在文件内容中搜索特定文本。"
    
    parameters = {
        "type": "object",
        "properties": {
            "search_type": {
                "type": "string",
                "enum": ["by_name", "by_content"],
                "description": "搜索类型：'by_name' 为按文件名查找；'by_content' 为搜索文件内的文本内容。"
            },
            "keyword": {
                "type": "string",
                "description": "要搜索的文件名片段或文本关键字"
            },
            "target_dir": {
                "type": "string",
                "description": "搜索的目标目录，默认建议为 '/'"
            }
        },
        "required": ["search_type", "keyword"]
    }

    def get_command(self, **kwargs) -> str:
        search_type = kwargs.get("search_type")
        keyword = kwargs.get("keyword")
        target_dir = kwargs.get("target_dir", "/")

        if search_type == "by_name":
            # 使用 find 按名称不区分大小写搜索，屏蔽权限报错，限制最多返回 20 条结果
            return f"find {target_dir} -iname '*{keyword}*' 2>/dev/null | head -n 20"
            
        elif search_type == "by_content":
            # 使用 grep 递归检索文本，同样屏蔽报错并限制返回数量
            return f"grep -rnI '{keyword}' {target_dir} 2>/dev/null | head -n 20"
            
        return f"find / -name '*{keyword}*' 2>/dev/null | head -n 10"