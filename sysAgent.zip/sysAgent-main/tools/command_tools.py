from .base_tool import BaseTool

class ExecuteCommandTool(BaseTool):
    name = "execute_general_command"
    description = "执行通用的 Linux Shell 命令，专门用于文件操作（如 rm, cp, mv, mkdir）、权限修改（如 chmod, chown）等基础运维任务。"
    
    parameters = {
        "type": "object",
        "properties": {
            "command": {
                "type": "string",
                "description": "需要执行的具体 Linux Shell 命令，例如 'rm -rf /tmp/test' 或 'chmod 755 /var/www'"
            }
        },
        "required": ["command"]
    }

    def get_command(self, **kwargs) -> str:
        # 直接返回大模型生成的命令，交给底层的 ssh_manager 和 risk_control 去进行安全校验
        return kwargs.get("command", "echo '空指令'")