from .base_tool import BaseTool

class CheckProcessTool(BaseTool):
    name = "check_process_and_port"
    description = "查询服务器的进程状态或端口占用情况。用于排查服务是否启动或端口冲突。"
    
    parameters = {
        "type": "object",
        "properties": {
            "query_type": {
                "type": "string",
                "enum": ["process_name", "port_number", "top_cpu"],
                "description": "查询维度。'process_name' 查指定进程名；'port_number' 查指定端口；'top_cpu' 查资源占用最高的进程。"
            },
            "keyword": {
                "type": "string",
                "description": "具体的进程名（如 nginx）或端口号（如 8080）"
            }
        },
        "required": ["query_type"]
    }

    def get_command(self, **kwargs) -> str:
        query_type = kwargs.get("query_type")
        keyword = kwargs.get("keyword", "")

        if query_type == "process_name" and keyword:
            # 查找特定进程，并排除 grep 自身的进程
            return f"ps aux | grep '{keyword}' | grep -v grep | head -n 15 || echo '未找到名为 {keyword} 的活跃进程。'"
            
        elif query_type == "port_number" and keyword:
            return f"lsof -i:{keyword} || echo '端口 {keyword} 目前非常空闲，未被占用。'"
            
        elif query_type == "top_cpu":
            # 抓取当前 CPU 占用前 5 的进程
            return "ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%cpu | head -n 6"
            
        return "ps aux | head -n 10"