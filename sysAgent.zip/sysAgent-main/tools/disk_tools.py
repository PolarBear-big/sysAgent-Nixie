from .base_tool import BaseTool

class CheckDiskTool(BaseTool):
    name = "check_disk_usage"
    description = "监测 Linux 服务器的磁盘使用情况，可以查看整体空间或特定目录的大小。"
    
    parameters = {
        "type": "object",
        "properties": {
            "check_type": {
                "type": "string",
                "enum": ["overall", "directory"],
                "description": "检查类型。'overall' 表示查看整体磁盘挂载情况；'directory' 表示查看特定目录占用的空间。"
            },
            "target_dir": {
                "type": "string",
                "description": "当 check_type 为 'directory' 时，需要指定目标目录路径，例如 '/var/log'"
            }
        },
        "required": ["check_type"]
    }

    def get_command(self, **kwargs) -> str:
        check_type = kwargs.get("check_type")
        
        if check_type == "overall":
            # df -h: 以人类可读格式显示文件系统磁盘空间使用情况
            # T 选项显示文件系统类型，排除 tmpfs 等干扰项
            return "df -hT --exclude-type=tmpfs --exclude-type=devtmpfs"
            
        elif check_type == "directory":
            target_dir = kwargs.get("target_dir", "/")
            # du -sh: 显示特定目录的总大小
            return f"du -sh {target_dir}"
            
        return "df -h"