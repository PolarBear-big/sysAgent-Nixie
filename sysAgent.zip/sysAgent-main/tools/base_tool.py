import copy

class BaseTool:
    name: str = ""
    description: str = ""
    parameters: dict = {}

    def get_tool_schema(self) -> dict:
        """返回供 LLM 识别的 JSON Schema"""
        schema_params = copy.deepcopy(self.parameters)
        if "properties" not in schema_params:
            schema_params["properties"] = {}
        
        schema_params["properties"]["use_sudo"] = {
            "type": "boolean",
            "description": "全局提权开关。默认 false。执行时若遇到 'Permission denied' 报错，必须停止并向用户申请授权，获批后方可将此参数设为 true 再次执行。",
            "default": False
        }
        
        schema_params["properties"]["force_execute"] = {
            "type": "boolean",
            "description": "风险确认开关。默认 false。若执行返回 '[风控拦截 - WARNING]'，必须向用户请求确认。获得明确同意后，将此参数设为 true 再次调用工具即可放行执行。",
            "default": False
        }
        
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": schema_params
            }
        }

    def get_command(self, **kwargs) -> str:
        """具体的执行逻辑，由子类实现"""
        raise NotImplementedError

    def build_executable_command(self, **kwargs) -> str:
        """全局命令拦截器：
        在 Agent 调用工具时，拦截 use_sudo 参数，并在子类命令外层统一包裹 sudo
        """
        # 提取并从字典中移除 use_sudo，防止传给未适配该参数的子类导致报错
        use_sudo = kwargs.pop("use_sudo", False)
        kwargs.pop("force_execute", False)
        
        raw_cmd = self.get_command(**kwargs)
        
        # 如果大模型决定提权，且命令并未以 sudo 开头，则全局统一加上前缀
        if use_sudo and not raw_cmd.strip().startswith("sudo"):
            return f"sudo {raw_cmd}"
            
        return raw_cmd