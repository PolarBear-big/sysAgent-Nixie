import paramiko
from security import check_command_safety
from config.logger import logger

class SSHManager:
    """
    负责与靶机建立 SSH 连接，并安全、受控地执行来自 Agent 的 Shell 命令。
    """
    def __init__(self, host, port, username, password=None, key_filename=None):
        self.host = host
        self.port = port
        self.username = username
        self.client = paramiko.SSHClient()
        # 自动接受未知的 SSH 密钥
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        
        logger.info(f"正在尝试连接到靶机 {username}@{host}:{port}...")
        try:
            # 支持密码登录or密钥登录
            if key_filename:
                self.client.connect(hostname=host, port=port, username=username, key_filename=key_filename, timeout=10)
            else:
                self.client.connect(hostname=host, port=port, username=username, password=password, timeout=10)
            logger.info("√ SSH 连接成功！靶机已就绪。")
        except Exception as e:
            logger.error(f"× SSH 连接失败: {str(e)}")
            raise ConnectionError(f"× SSH 连接失败，请检查网络或凭证: {str(e)}")

    def execute_command(self, command: str, timeout: int = 15, force_execute: bool = False) -> str:
        """
        在靶机上执行命令并返回结果。
        包含超时控制、错误码捕获。
        """
        # 安全风控拦截
        safety_report = check_command_safety(command)
        if safety_report["level"] == "FATAL":
            logger.warning(f"[系统硬拦截] 拒绝执行: {command} | 原因: {safety_report['reason']}")
            # 将拦截结果返回给大模型，大模型会据此生成“行为可解释”的反馈
            return f"[风控拦截] 系统拒绝了该操作，因为该命令涉及高风险行为：{safety_report['reason']}。"
            
        elif safety_report["level"] == "WARNING":
            if force_execute:
                logger.info(f"   [授权通过] 检测到 force_execute=True，放行 WARNING 级敏感指令: {command}")
            else:
                logger.warning(f"[风险预警] Agent 试图执行敏感操作: {command} | 原因: {safety_report['reason']}")
                return f"[风控拦截 - WARNING] 敏感操作已被挂起。原因：{safety_report['reason']}。请务必向Boss解释风险，并询问是否确认执行。"
        
        # 执行命令
        logger.info(f"\n[SSH 执行] 正在下发指令 -> {command}")
        
        try:
            # 执行命令，设置 timeout，防止被交互式命令挂起主线程
            stdin, stdout, stderr = self.client.exec_command(command, timeout=timeout)
            
            out = stdout.read().decode('utf-8').strip()
            err = stderr.read().decode('utf-8').strip()
            exit_status = stdout.channel.recv_exit_status()
            
            if exit_status != 0:
                logger.error(f"[执行异常] 退出码: {exit_status}\n错误信息: {err}")
                return f"[执行异常] 退出码: {exit_status}\n错误信息: {err}\n标准输出: {out}"
                
            if not out and not err:
                return "[执行成功] 命令已执行，无终端输出。"
                
            return out
            
        except paramiko.SSHException as e:
            logger.error(f"[SSH 通信错误] {str(e)}")
            return f"[SSH 通信错误] {str(e)}"
        except Exception as e: 
            logger.error(f"[执行超时或系统崩溃] {str(e)}")
            return f"[执行超时或系统崩溃] {str(e)}"

    def close(self):
        """关闭 SSH 连接"""
        if self.client:
            self.client.close()
            logger.info("SSH 连接已安全关闭。")