from zai import ZhipuAiClient
import json

class LLMClient:
    """
    负责与大模型 API 沟通，把用户的对话、系统的上下文以及工具说明书打包发给大模型，并把大模型的决定返回。
    """
    # def __init__(self, api_key: str, base_url: str, model: str):
    def __init__(self, api_key: str, model: str):
        # # 初始化
        # self.client = OpenAI(
        #     api_key=api_key,
        #     base_url=base_url
        # )
        # self.model = model
        
        self.client = ZhipuAiClient(api_key=api_key)
        self.model = model

    def chat_with_tools(self, messages: list, tools: list = None) -> dict:
        """
        发送对话并携带工具列表，获取大模型的响应。
        
        :param messages: 对话上下文列表，例如 [{"role": "user", "content": "查一下磁盘"}]
        :param tools: 工具的 JSON Schema 列表
        :return: 包含响应内容的字典
        """
        
        # 组装请求参数
        kwargs = {
            "model": self.model,
            "messages": messages,
            "temperature": 0.1,
        }
        
        # 如果传入了可选工具，告诉大模型可以自主选择使用
        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = "auto"
            
        try:
            response = self.client.chat.completions.create(**kwargs)
            message = response.choices[0].message
            
            # 解析大模型的响应
            if hasattr(message, "tool_calls") and message.tool_calls:
                # 大模型决定调用工具
                tool_call = message.tool_calls[0]
                raw_arguments = tool_call.function.arguments
                try:
                    parsed_args = json.loads(raw_arguments)
                except json.JSONDecodeError:
                    cleaned_args = raw_arguments.strip().strip('`').removeprefix('json').strip()
                    try:
                        parsed_args = json.loads(cleaned_args)
                    except json.JSONDecodeError:
                        raise ValueError(f"大模型返回了非法的 JSON 参数格式: {raw_arguments}")

                return {
                    "type": "tool_call",
                    "tool_call_id": tool_call.id,
                    "tool_name": tool_call.function.name,
                    "tool_args": parsed_args,
                    "raw_message": message
                }
            else:
                # 大模型认为不需要调用工具，直接给出纯文本回复
                return {
                    "type": "text",
                    "content": message.content,
                    "raw_message": message
                }
        except Exception as e:
            return {
                "type": "error",
                "content": f"大模型接口调用失败: {str(e)}"
            }
            