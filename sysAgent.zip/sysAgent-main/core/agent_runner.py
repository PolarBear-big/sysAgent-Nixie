import json
from .llm_client import LLMClient
from .ssh_manager import SSHManager
from tools import get_all_tool_schemas, get_tool_by_name
from config.logger import logger

class AgentRunner:
    """
    维护对话上下文，串联 LLM 的意图识别与 SSH 的底层执行。
    """
    def __init__(self, llm_client: LLMClient, ssh_manager: SSHManager):
        self.llm_client = llm_client
        self.ssh_manager = ssh_manager
        
        # 加载所有可用工具的使用描述
        self.tools_schema = get_all_tool_schemas()

        self.messages = [
            {
                "role": "system", 
                "content": (
                    "你叫 Nixie，是一位专属的 Linux 高级智能代理。你的职责是全心全意辅助Boss管理服务器，确保系统高效与安全。\n\n"
                    
                    "【一、 沟通与人设】\n"
                    "- 角色设定：时刻保持干练的口吻，称呼用户为'Boss'。\n"
                    "- 拒绝机器味：【绝对禁止】使用“根据查询结果如下”等冷冰冰的套话。废话少说，一语道破核心状态。\n"
                    "- 数据拟人化：将生硬的系统指标融进自然对话中。（如：“Boss，Nixie巡视发现目前CPU占用最高的是XXX进程，系统很健康哦～”）\n\n"
                    
                    "【二、 执行与风控纪律（最高优先级）】\n"
                    "- 默认权限：所有工具默认以普通用户执行。遇到被系统风控拦截时，用关切的口吻向Boss报告并提供替代方案。\n"
                    "- 智能合并审批：若你预判即将执行的操作（如删用户、停服务、改配置）极大概率会【同时】触发“风控拦截”与“权限不足”，你【必须在第一次对话时，一并】向Boss解释风险并索要双重授权。\n"
                    "- 豁免执行：一旦获得Boss同意，你必须在工具调用中【同时携带】`force_execute=true` 和 `use_sudo=true` 发起执行，坚决杜绝让Boss反复确认的繁琐流程。"
                )
            }
        ]

    def process_user_input(self, user_input: str):
        """处理单次用户输入，可能触发多次 LLM 调用（思维链/工具链），返回 LLM 的最终自然语言结果"""
        
        # 记录用户的最新指令
        self.messages.append({"role": "user", "content": user_input})
        logger.info(f"===> [用户输入]:\n{user_input}")
        
        while True:
            # 滑动窗口记忆控制
            MAX_MEMORY_MESSAGES = 15
            if len(self.messages) > MAX_MEMORY_MESSAGES:
                self.messages = [self.messages[0]] + self.messages[-(MAX_MEMORY_MESSAGES-1):]
                
            # 带着历史记录和工具列表，调用LLM
            response = self.llm_client.chat_with_tools(self.messages, self.tools_schema)
            
            # 处理大模型接口异常
            if response["type"] == "error":
                logger.error(f"[Agent 故障] {response['content']}")
                return f"系统发生故障：{response['content']}"
                
            # 如果大模型决定直接说话（任务结束或寒暄）
            if response["type"] == "text":
                # 把大模型的话记入历史，保持上下文连贯
                self.messages.append({"role": "assistant", "content": response["content"]})
                logger.info(f"[Agent 反馈]:\n{response['content']}\n")
                return response["content"]
                
                
            # 如果大模型决定使用工具（核心执行流）
            elif response["type"] == "tool_call":
                tool_name = response["tool_name"]
                tool_args = response["tool_args"]
                
                # 将大模型使用动作的考虑记入对话历史
                self.messages.append(response["raw_message"])
                logger.info(f"[Agent 思考] 决定使用工具: {tool_name}, 参数: {tool_args}")
                
                # 在本地工具库中找到对应工具，生成 Shell 命令
                tool_instance = get_tool_by_name(tool_name)
                if not tool_instance:
                    execution_result = f"[错误] 找不到名为 {tool_name} 的工具。"
                    logger.error(execution_result)
                else:
                    force_exec = tool_args.get("force_execute", False)
                    command_to_run = tool_instance.build_executable_command(**tool_args)
                    # 命令推送到靶机执行
                    execution_result = self.ssh_manager.execute_command(command_to_run, force_execute=force_exec)
                
                # 终端输出打包，塞回对话历史
                self.messages.append({
                    "role": "tool",
                    "tool_call_id": response["tool_call_id"],
                    "name": tool_name,
                    "content": execution_result
                })
                
                # 注意：这里没有 break，循环继续。
                # 当大模型看到执行结果后，会生成最终的自然语言反馈（变成 type: "text" 并 break 出循环）。

    def start_interactive_shell(self):
        """启动交互式终端界面"""
        logger.info("\n" + "="*50)
        logger.info("AI Sysadmin Agent 已启动。输入 'exit' 或 'quit' 退出。")
        logger.info("="*50)
        
        try:
            while True:
                user_input = input("\n[User]> ").strip()
                if not user_input:
                    continue
                if user_input.lower() in ['exit', 'quit']:
                    print("退出系统。")
                    break
                    
                self.process_user_input(user_input)
                
        except KeyboardInterrupt:
            print("\n强制退出...")
        finally:
            self.ssh_manager.close()