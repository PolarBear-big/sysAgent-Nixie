import logging
import os
from logging.handlers import RotatingFileHandler

def setup_logger(name="SysadminAgent"):
    # 确保日志目录存在
    log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs')
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, 'agent_run.log')

    # 创建 Logger
    logger = logging.getLogger(name)
    
    # 如果已经配置过，直接返回，避免重复打印
    if logger.handlers:
        return logger
        
    logger.setLevel(logging.DEBUG) # 捕获所有级别的日志

    # 定义日志的统一格式：时间戳 - 级别 - 模块名 - 具体信息
    formatter = logging.Formatter(
        fmt='[%(asctime)s] [%(levelname)s] %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    # 配置文件输出 Handler (最大 5MB，保留 3 个备份)
    file_handler = RotatingFileHandler(log_file, maxBytes=5*1024*1024, backupCount=3, encoding='utf-8')
    file_handler.setLevel(logging.INFO) # 写入文件的最低级别为 INFO
    file_handler.setFormatter(formatter)

    # 2配置控制台输出 Handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO) # 控制台只显示 INFO 及以上
    console_formatter = logging.Formatter('%(message)s') 
    console_handler.setFormatter(console_formatter)

    # 将这两个 Handler 挂载到 Logger 上
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger

# 实例化一个全局可用的 logger
logger = setup_logger()