import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    """全局配置类，集中管理所有的环境变量"""
    
    # LLM 配置
    LLM_API_KEY = os.getenv("LLM_API_KEY")
    # LLM_BASE_URL = os.getenv("LLM_BASE_URL", "https://api.deepseek.com/v1")
    LLM_MODEL_NAME = os.getenv("LLM_MODEL_NAME", "deepseek-chat")
    
    # SSH 配置
    SSH_HOST = os.getenv("SSH_HOST")
    SSH_PORT = int(os.getenv("SSH_PORT", 22))
    SSH_USERNAME = os.getenv("SSH_USERNAME", "root")
    SSH_PASSWORD = os.getenv("SSH_PASSWORD")

    @classmethod
    def check_config(cls):
        """启动前检查必要的配置是否缺失"""
        missing = []
        if not cls.LLM_API_KEY: missing.append("LLM_API_KEY")
        if not cls.SSH_HOST: missing.append("SSH_HOST")
        if not cls.SSH_PASSWORD: missing.append("SSH_PASSWORD")
        
        if missing:
            raise ValueError(f"缺少必要的环境变量配置: {', '.join(missing)}。请检查 .env 文件。")

# 实例化一个全局唯一的配置对象
config = Settings()